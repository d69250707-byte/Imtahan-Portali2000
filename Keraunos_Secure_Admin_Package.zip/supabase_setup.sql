-- Supabase SQL Editor-də işə sal. Mövcud açıq siyasətləri də aradan qaldırır.
create table if not exists public.participants (
  id text primary key,
  name text not null,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  status text not null default 'İmtahandadır'
);

alter table public.participants enable row level security;

-- Köhnə prototip siyasətlərini sil.
drop policy if exists "anon can read participants" on public.participants;
drop policy if exists "anon can add participants" on public.participants;
drop policy if exists "anon can update participants" on public.participants;
drop policy if exists "anon can delete participants" on public.participants;

-- İmtahan səhifəsinə yeni iştirakçı yazmağa və statusunu yeniləməyə icazə ver.
-- İştirakçı siyahısını oxumaq/silmək yalnız server funksiyasının service-role açarı ilə mümkündür.
drop policy if exists "public can insert participant" on public.participants;
create policy "public can insert participant"
on public.participants for insert to anon with check (true);

drop policy if exists "public can update participant" on public.participants;
create policy "public can update participant"
on public.participants for update to anon using (true) with check (true);

grant usage on schema public to anon;
grant insert, update on public.participants to anon;
revoke select, delete on public.participants from anon, authenticated;
